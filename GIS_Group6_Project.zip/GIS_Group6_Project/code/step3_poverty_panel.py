"""
STEP 4: Poverty model with 2 time points (NFHS-4 ~2015 + NFHS-5 ~2021).
Validation: Leave-One-District-Out (dono saal ek saath hold-out, taaki leakage na ho).
Run: python step3_poverty_panel.py   (ntl_wb_districts.csv aur ground_truth.csv same folder me)
"""
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from scipy.stats import pearsonr
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import LeaveOneGroupOut, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error

# NFHS-4 (2015-16) headcount ratio %, NITI Aayog MPI Progress Review 2023 (old 2015 district boundaries)
mpi15 = {'Bankura':26.99,'Barddhaman':20.33,'Birbhum':27.35,'Dakshin Dinajpur':22.48,'Darjiling':11.32,'East Midnapore':14.19,
 'Haora':12.84,'Hugli':14.93,'Jalpaiguri':21.83,'Kochbihar':21.90,'Kolkata':2.72,'Maldah':34.48,'Murshidabad':27.23,'Nadia':11.07,
 'North 24 Parganas':9.80,'Puruliya':49.69,'South 24 Parganas':28.10,'Uttar Dinajpur':42.84,'West Midnapore':23.82}

ntl = pd.read_csv("ntl_wb_districts.csv")
gt = pd.read_csv("ground_truth.csv")
mpi21 = dict(zip(gt.district, gt.mpi))

rows = []
for yr, m in [(2015, mpi15), (2021, mpi21)]:
    d = ntl[ntl.year == yr].copy()
    d["mpi"] = d.district.map(m)
    rows.append(d)
df = pd.concat(rows).dropna(subset=["mpi"]).reset_index(drop=True)

# Population ki zarurat nahi: ntl_sum/ntl_mean = pixel count (area proxy)
df["area_km2"] = df.ntl_sum / df.ntl_mean * 0.25
df["lit_frac"] = (df.lit_area_km2 / df.area_km2).clip(0, 1)
df["ln_ntl_mean"] = np.log(df.ntl_mean)
df["is2021"] = (df.year == 2021).astype(int)
print(f"Rows: {len(df)} (districts: {df.district.nunique()})")

def loo(feats, data):
    X, y, g = data[feats].values, data.mpi.values, data.district.values
    p = cross_val_predict(LinearRegression(), X, y, cv=LeaveOneGroupOut(), groups=g)
    return p, r2_score(y, p), np.sqrt(mean_squared_error(y, p))

res = []
for name, feats, data in [
    ("2021 only: ln_ntl_mean", ["ln_ntl_mean"], df[df.year == 2021]),
    ("2021 only: lit_frac", ["lit_frac"], df[df.year == 2021]),
    ("Panel: ln_ntl_mean", ["ln_ntl_mean"], df),
    ("Panel: lit_frac", ["lit_frac"], df),
    ("Panel: ln_ntl_mean + lit_frac", ["ln_ntl_mean", "lit_frac"], df),
    ("Panel: ln_ntl_mean + lit_frac + year", ["ln_ntl_mean", "lit_frac", "is2021"], df),
]:
    p, r2, rmse = loo(feats, data.reset_index(drop=True))
    r = pearsonr(data[feats[0]], data.mpi)[0]
    res.append(dict(model=name, n=len(data), R2=r2, RMSE=rmse, pearson_first_feature=r))
res = pd.DataFrame(res); print(res.round(3).to_string(index=False))
res.to_csv("outputs/poverty_panel_metrics.csv", index=False)

best = ["ln_ntl_mean", "lit_frac"]
p, r2, rmse = loo(best, df)
df["mpi_pred"] = p
df.to_csv("outputs/poverty_panel_results.csv", index=False)
plt.figure(figsize=(5.5, 5))
for yr, c in [(2015, "tab:orange"), (2021, "tab:blue")]:
    s = df[df.year == yr]; plt.scatter(s.mpi, s.mpi_pred, c=c, label=str(yr), alpha=.85)
lim = [0, df.mpi.max() + 3]; plt.plot(lim, lim, "k--", lw=1)
plt.xlabel("Actual MPI headcount (%)"); plt.ylabel("Predicted (leave-one-district-out)")
plt.title(f"Poverty from NTL (panel), R²={r2:.2f}"); plt.legend(); plt.tight_layout()
plt.savefig("outputs/poverty_panel_pred_vs_actual.png", dpi=200)
