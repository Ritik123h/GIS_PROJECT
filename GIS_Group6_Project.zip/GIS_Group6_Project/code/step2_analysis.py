"""
STEP 2: NTL se district-level GDP aur poverty estimation.

Inputs (same folder me rakho):
  ntl_wb_districts.csv     -> GEE se (district, year, ntl_sum, ntl_mean, lit_area_km2)
  ground_truth.csv         -> aapko banana hai: district, year, gddp, population, mpi
                              (gddp in Rs crore, mpi in % poor, population in persons)
  wb_districts_boundary.shp (optional, map ke liye)

Run:  python step2_analysis.py
Install: pip install pandas numpy scikit-learn scipy matplotlib geopandas
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import pearsonr, spearmanr
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error

OUT = "outputs"
os.makedirs(OUT, exist_ok=True)


def norm(s):
    return s.astype(str).str.strip().str.lower().str.replace(r"[^a-z0-9]", "", regex=True)


# ---------- 1. Load + merge ----------
ntl = pd.read_csv("ntl_wb_districts.csv")
gt = pd.read_csv("ground_truth.csv")
ntl["key"], gt["key"] = norm(ntl["district"]), norm(gt["district"])

df = ntl.merge(gt.drop(columns=["district"]), on=["key", "year"], how="inner")
if df.empty:
    raise SystemExit("Merge empty: district names ya year match nahi kar rahe. "
                     "ground_truth.csv ke naam GEE ke ADM2_NAME jaise rakho.")

df["ntl_pc"] = df["ntl_sum"] / df["population"]
df["gddp_pc"] = df["gddp"] * 1e7 / df["population"]  # Rs per person
df["ln_ntl"] = np.log(df["ntl_sum"] + 1)
df["ln_gddp"] = np.log(df["gddp"])
df["ln_ntl_pc"] = np.log(df["ntl_pc"] + 1e-9)
df.to_csv(f"{OUT}/merged_dataset.csv", index=False)
print(f"Merged rows: {len(df)}, districts: {df['key'].nunique()}, years: {sorted(df['year'].unique())}")

# ---------- 2. Correlations ----------
rows = []
for target in ["gddp", "mpi"]:
    d = df.dropna(subset=[target])
    for f in ["ntl_sum", "ntl_mean", "lit_area_km2", "ntl_pc"]:
        r, p = pearsonr(d[f], d[target])
        rho, _ = spearmanr(d[f], d[target])
        rows.append(dict(target=target, feature=f, pearson=r, p_value=p, spearman=rho))
pd.DataFrame(rows).to_csv(f"{OUT}/correlations.csv", index=False)
print(pd.DataFrame(rows).round(3).to_string(index=False))


# ---------- 3. Models (Leave-One-Out CV, kyunki districts kam hain) ----------
def run_models(d, target, feats, log_target, tag):
    X, y = d[feats].values, d[target].values
    yt = np.log(y) if log_target else y
    res, preds = [], {}
    for name, model in [("Linear", LinearRegression()),
                        ("RandomForest", RandomForestRegressor(n_estimators=300, random_state=42))]:
        p = cross_val_predict(model, X, yt, cv=LeaveOneOut())
        p = np.exp(p) if log_target else p
        res.append(dict(target=tag, model=name,
                        R2=r2_score(y, p), RMSE=np.sqrt(mean_squared_error(y, p))))
        preds[name] = p
    return pd.DataFrame(res), preds


# Latest year with ground truth pe cross-section model
latest = df["year"].max()
cs = df[df["year"] == latest].dropna(subset=["gddp", "mpi"]).reset_index(drop=True)
print(f"\nCross-section year: {latest}, districts: {len(cs)}")

feats = ["ln_ntl", "lit_area_km2", "ln_ntl_pc"]
r_gdp, p_gdp = run_models(cs, "gddp", feats, True, "GDDP")
r_pov, p_pov = run_models(cs, "mpi", feats, False, "Poverty (MPI)")
metrics = pd.concat([r_gdp, r_pov])
metrics.to_csv(f"{OUT}/model_metrics.csv", index=False)
print(metrics.round(3).to_string(index=False))

# ---------- 4. Plots: predicted vs actual ----------
fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
for a, (title, y, p) in zip(ax, [("GDDP", cs["gddp"], p_gdp), ("Poverty (MPI %)", cs["mpi"], p_pov)]):
    a.scatter(y, p["RandomForest"], label="Random Forest", alpha=.8)
    a.scatter(y, p["Linear"], label="Linear", alpha=.8, marker="x")
    lim = [min(y.min(), p["Linear"].min()), max(y.max(), p["Linear"].max())]
    a.plot(lim, lim, "k--", lw=1)
    a.set_xlabel("Actual"); a.set_ylabel("Predicted (LOO-CV)"); a.set_title(title); a.legend()
plt.tight_layout(); plt.savefig(f"{OUT}/pred_vs_actual.png", dpi=200); plt.close()

plt.figure(figsize=(5.5, 4.5))
plt.scatter(cs["ln_ntl"], cs["ln_gddp"])
m, c = np.polyfit(cs["ln_ntl"], cs["ln_gddp"], 1)
xs = np.linspace(cs["ln_ntl"].min(), cs["ln_ntl"].max(), 50)
plt.plot(xs, m * xs + c, "r-")
plt.xlabel("ln(NTL sum)"); plt.ylabel("ln(GDDP)"); plt.title("Log-log: NTL vs GDDP")
plt.tight_layout(); plt.savefig(f"{OUT}/loglog_ntl_gddp.png", dpi=200); plt.close()

# ---------- 5. Residual analysis ----------
cs["gddp_pred_lin"] = p_gdp["Linear"]
cs["gddp_pred_rf"] = p_gdp["RandomForest"]
cs["gddp_resid_pct"] = (cs["gddp"] - cs["gddp_pred_rf"]) / cs["gddp"] * 100
cs["mpi_pred_lin"] = p_pov["Linear"]
cs["mpi_pred_rf"] = p_pov["RandomForest"]
cs["mpi_resid"] = cs["mpi"] - cs["mpi_pred_rf"]
cs.to_csv(f"{OUT}/district_results.csv", index=False)
print("\nSabse zyada galat predict hue districts (GDDP):")
print(cs.reindex(cs["gddp_resid_pct"].abs().sort_values(ascending=False).index)
        [["district", "gddp", "gddp_pred_rf", "gddp_resid_pct"]].head(5).round(1).to_string(index=False))

# ---------- 6. Choropleth maps (optional) ----------
shp = "wb_districts_boundary.shp"
if os.path.exists(shp):
    import geopandas as gpd
    g = gpd.read_file(shp)
    g["key"] = norm(g["ADM2_NAME"])
    g = g.merge(cs, on="key", how="left")
    for col, ttl, cmap in [("gddp", "Actual GDDP", "YlGn"), ("gddp_pred_lin", "Predicted GDDP (Linear, from NTL)", "YlGn"),
                           ("mpi", "Actual Poverty (MPI %)", "OrRd"), ("mpi_pred_lin", "Predicted Poverty (Linear, from NTL)", "OrRd")]:
        ax = g.plot(column=col, cmap=cmap, legend=True, edgecolor="k", linewidth=.4,
                    figsize=(5, 6), missing_kwds={"color": "lightgrey"})
        ax.set_title(ttl); ax.axis("off")
        plt.savefig(f"{OUT}/map_{col}.png", dpi=200, bbox_inches="tight"); plt.close()
    g.to_file(f"{OUT}/results_districts.gpkg", driver="GPKG")  # QGIS me direct open karo
else:
    print("Boundary shapefile nahi mila, maps skip.")

print(f"\nDone. Sab output '{OUT}/' folder me hai.")
