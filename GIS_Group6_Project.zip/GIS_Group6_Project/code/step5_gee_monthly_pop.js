// STEP 5: Earth Engine Code Editor me paste karke Run karo.
// Output (Drive me 2 CSV): ntl_monthly_wb.csv  aur  worldpop_wb_districts.csv

var districts = ee.FeatureCollection('FAO/GAUL/2015/level2')
  .filter(ee.Filter.eq('ADM1_NAME', 'West Bengal'));

// ---- 1. Monthly VIIRS light, Jan 2018 - Dec 2022 (COVID analysis) ----
var monthly = ee.ImageCollection('NOAA/VIIRS/DNB/MONTHLY_V1/VCMSLCFG');
var months = ee.List.sequence(0, 59);

var monthlyRows = months.map(function (m) {
  var start = ee.Date.fromYMD(2018, 1, 1).advance(m, 'month');
  var img = ee.Image(monthly.filterDate(start, start.advance(1, 'month')).first());
  var stack = img.select('avg_rad').max(0).rename('rad')
    .addBands(img.select('cf_cvg').rename('cf'));
  var stats = stack.reduceRegions({
    collection: districts,
    reducer: ee.Reducer.mean().combine(ee.Reducer.sum(), '', true),
    scale: 500,
    tileScale: 4
  });
  return stats.map(function (f) {
    return ee.Feature(null, {
      district: f.get('ADM2_NAME'),
      month: start.format('YYYY-MM'),
      rad_sum: f.get('rad_sum'),
      rad_mean: f.get('rad_mean'),
      cloud_free_obs: f.get('cf_mean')   // kam value = badal/monsoon, data bharosemand nahi
    });
  });
});

Export.table.toDrive({
  collection: ee.FeatureCollection(monthlyRows).flatten(),
  description: 'ntl_monthly_wb',
  fileFormat: 'CSV'
});

// ---- 2. WorldPop population 2020 per district ----
var pop = ee.ImageCollection('WorldPop/GP/100m/pop')
  .filter(ee.Filter.eq('country', 'IND'))
  .filter(ee.Filter.eq('year', 2020))
  .mosaic();

var popStats = pop.reduceRegions({
  collection: districts,
  reducer: ee.Reducer.sum(),
  scale: 100,
  tileScale: 16
}).map(function (f) {
  return ee.Feature(null, { district: f.get('ADM2_NAME'), pop2020: f.get('sum') });
});

Export.table.toDrive({
  collection: popStats,
  description: 'worldpop_wb_districts',
  fileFormat: 'CSV'
});
