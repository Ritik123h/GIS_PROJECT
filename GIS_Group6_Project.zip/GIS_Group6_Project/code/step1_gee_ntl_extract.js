// STEP 1: Google Earth Engine Code Editor me paste karo aur Run karo.
// Output: Drive me "ntl_wb_districts.csv" (district x year)

var districts = ee.FeatureCollection('FAO/GAUL/2015/level2')
  .filter(ee.Filter.eq('ADM1_NAME', 'West Bengal'));

// VIIRS annual composites: V21 (2014-2021) + V22 (2022-2023)
var v21 = ee.ImageCollection('NOAA/VIIRS/DNB/ANNUAL_V21');
var v22 = ee.ImageCollection('NOAA/VIIRS/DNB/ANNUAL_V22');
var ntl = v21.merge(v22).select('average');

var years = ee.List.sequence(2014, 2023);

var results = years.map(function (y) {
  y = ee.Number(y);
  var img = ntl
    .filterDate(ee.Date.fromYMD(y, 1, 1), ee.Date.fromYMD(y, 12, 31))
    .first();
  img = ee.Image(img).max(0); // negative radiance hatao

  var lit = img.gt(0.5).multiply(ee.Image.pixelArea()).divide(1e6).rename('lit_km2');
  var stack = img.rename('ntl').addBands(lit);

  var stats = stack.reduceRegions({
    collection: districts,
    reducer: ee.Reducer.sum().combine(ee.Reducer.mean(), '', true),
    scale: 500,
    tileScale: 4
  });

  return stats.map(function (f) {
    return ee.Feature(null, {
      district: f.get('ADM2_NAME'),
      year: y,
      ntl_sum: f.get('ntl_sum'),
      ntl_mean: f.get('ntl_mean'),
      lit_area_km2: f.get('lit_km2_sum')
    });
  });
});

var table = ee.FeatureCollection(results).flatten();
print(table.limit(10));

Export.table.toDrive({
  collection: table,
  description: 'ntl_wb_districts',
  fileFormat: 'CSV'
});

// District boundary bhi export karo (QGIS maps ke liye)
Export.table.toDrive({
  collection: districts.select(['ADM2_NAME']),
  description: 'wb_districts_boundary',
  fileFormat: 'SHP'
});
