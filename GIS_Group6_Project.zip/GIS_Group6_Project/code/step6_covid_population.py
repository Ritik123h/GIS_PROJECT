"""
STEP 6: (a) COVID-19 impact on nighttime light, (b) NTL vs population (WorldPop).
Needs: ntl_monthly_wb.csv, worldpop_wb_districts.csv, ntl_wb_districts.csv, ground_truth.csv
Run: python step6_covid_population.py
"""
import numpy as np, pandas as pd, matplotlib.pyplot as plt, json
from scipy.stats import pearsonr, spearmanr
OUT = "outputs"; R = {}
m = pd.read_csv("ntl_monthly_wb.csv"); m["year"] = m.month.str[:4].astype(int); m["mo"] = m.month.str[5:].astype(int)

# ---------- (a) COVID ----------
def win(months, y):  # district total light in a window of months of year y
    s = m[(m.year == y) & (m.mo.isin(months))].groupby("district").rad_sum.sum()
    return s
W = [4, 5]                                   # lockdown window (Apr-May); dry-season months with usable coverage
l18, l19, l20, l21 = (win(W, y) for y in (2018, 2019, 2020, 2021))
chg20 = (l20 / l19 - 1) * 100                # lockdown 2020 vs 2019
chg21 = (l21 / l19 - 1) * 100                # second wave 2021 vs 2019
plc = (l19 / l18 - 1) * 100                  # placebo: normal year-to-year change 2019 vs 2018
band = 1.96 * plc.std()                      # normal range (about 95%)
state = lambda a, b: (a.sum() / b.sum() - 1) * 100
R["covid"] = dict(state_2020_vs_2019=round(state(l20, l19), 1), state_2021_vs_2019=round(state(l21, l19), 1),
                  state_placebo_2019_vs_2018=round(state(l19, l18), 1), band=round(band, 1),
                  n_outside_2020=int((chg20.abs() > band).sum()), n_down_2020=int((chg20 < 0).sum()),
                  worst2020=chg20.sort_values().head(3).round(1).to_dict(), best2020=chg20.sort_values().tail(3).round(1).to_dict(),
                  corr_cf_noise=round(float(m[m.mo.isin(W)].cloud_free_obs.median()), 1))
# low-coverage months share
cf = m.pivot_table(index="mo", columns="year", values="cloud_free_obs", aggfunc="median")
R["covid"]["monsoon_cf_median_Jun_Sep"] = round(float(cf.loc[6:9].values.mean()), 1)
R["covid"]["dry_cf_median_Oct_May"] = round(float(cf.loc[[1,2,3,4,5,10,11,12]].values.mean()), 1)

fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.5))
st = m.groupby(["year", "mo"]).rad_sum.sum().unstack(0) / 1e5
for y in st.columns: ax[0].plot(st.index, st[y], marker="o", ms=3, lw=2 if y == 2020 else 1, label=str(y))
ax[0].axvspan(5.5, 9.5, color="grey", alpha=.15); ax[0].text(6.2, st.values.min(), "monsoon\n(unreliable)", fontsize=8)
ax[0].axvspan(3.5, 5.5, color="red", alpha=.08); ax[0].set_xticks(range(1, 13))
ax[0].set_xlabel("Month"); ax[0].set_ylabel("Total light, West Bengal (x10^5)"); ax[0].set_title("Monthly nighttime light, 2018-2022"); ax[0].legend(fontsize=8)
o = chg20.sort_values()
ax[1].barh(o.index, o.values, color=["#C0392B" if v < 0 else "#2A5D8F" for v in o.values])
ax[1].axvspan(-band, band, color="grey", alpha=.2); ax[1].axvline(0, c="k", lw=.8)
ax[1].set_xlabel("Change in light, Apr-May 2020 vs Apr-May 2019 (%)"); ax[1].set_title("Lockdown change by district\n(grey = normal year-to-year range)")
plt.tight_layout(); plt.savefig(f"{OUT}/extra_covid.png", dpi=200); plt.close()

# ---------- (b) Population ----------
pop = pd.read_csv("worldpop_wb_districts.csv")[["district", "pop2020"]]
ann = pd.read_csv("ntl_wb_districts.csv"); ann = ann[ann.year == 2020][["district", "ntl_sum", "lit_area_km2"]]
gt = pd.read_csv("ground_truth.csv")[["district", "population", "gddp"]]
d = ann.merge(pop, on="district").merge(gt, on="district")
d["ntl_pc"] = d.ntl_sum / d.pop2020
x, y = np.log(d.ntl_sum), np.log(d.pop2020)
b, a = np.polyfit(x, y, 1); r = pearsonr(x, y)[0]
d["res"] = y - (a + b * x)
R["pop"] = dict(total_worldpop_M=round(d.pop2020.sum() / 1e6, 1), r_loglog=round(r, 2), r2=round(r * r, 2),
                spearman=round(spearmanr(d.ntl_sum, d.pop2020)[0], 2), slope=round(b, 2),
                r_vs_gddp_pop=round(pearsonr(np.log(d.pop2020), np.log(d.population))[0], 2),
                high_pc=d.sort_values("ntl_pc").tail(3)[["district"]].district.tolist(), low_pc=d.sort_values("ntl_pc").head(3).district.tolist(),
                pc_ratio_high_low=round(d.ntl_pc.max() / d.ntl_pc.min(), 1),
                above=d.sort_values("res").tail(3).district.tolist(), below=d.sort_values("res").head(3).district.tolist())
d.to_csv(f"{OUT}/ntl_population_2020.csv", index=False)
fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.5))
ax[0].scatter(x, y)
for _, rr in d.iterrows(): ax[0].annotate(rr.district, (np.log(rr.ntl_sum), np.log(rr.pop2020)), fontsize=6.5, xytext=(3, 3), textcoords="offset points")
xs = np.linspace(x.min(), x.max(), 50); ax[0].plot(xs, a + b * xs, "r-")
ax[0].set_xlabel("ln(NTL sum, 2020)"); ax[0].set_ylabel("ln(population, WorldPop 2020)"); ax[0].set_title(f"NTL vs population, r = {r:.2f}")
o = d.sort_values("ntl_pc"); ax[1].barh(o.district, o.ntl_pc, color="#2A5D8F"); ax[1].set_xlabel("NTL per person (2020)"); ax[1].set_title("Light per person")
plt.tight_layout(); plt.savefig(f"{OUT}/extra_population.png", dpi=200); plt.close()
json.dump(R, open(f"{OUT}/extra_results_covid_pop.json", "w"), indent=1); print(json.dumps(R, indent=1))
