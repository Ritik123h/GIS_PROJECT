"""
STEP 5: Extra analyses (easy add-ons): NTL growth, inequality (Gini/Lorenz),
metro vs rest comparison, spatial autocorrelation (Moran's I).
Run: python step4_extra_analysis.py   (needs files from step2 + wb_districts_boundary.shp)
"""
import numpy as np, pandas as pd, geopandas as gpd, matplotlib.pyplot as plt, json
OUT = "outputs"
ntl = pd.read_csv("ntl_wb_districts.csv")
res = pd.read_csv(f"{OUT}/district_results.csv")
res["ln_resid"] = np.log(res.gddp) - np.log(res.gddp_pred_lin)

# 1. NTL growth 2014 -> 2021 (VIIRS V21 only, avoids version change)
a = ntl[ntl.year == 2014].set_index("district").ntl_sum
b = ntl[ntl.year == 2021].set_index("district").ntl_sum
cagr = ((b / a) ** (1 / 7) - 1) * 100
state_cagr = ((b.sum() / a.sum()) ** (1 / 7) - 1) * 100

# 2. Gini
def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    return (2 * np.sum((np.arange(1, n + 1)) * x) / (n * x.sum())) - (n + 1) / n
def lorenz(x):
    x = np.sort(np.asarray(x, float)); c = np.insert(np.cumsum(x) / x.sum(), 0, 0)
    return np.linspace(0, 1, len(c)), c
g14 = gini(a.values); g21 = gini(b.values)
gpc = gini(res.ntl_sum / res.population)
gg = gini(res.gddp)

# 3. Metro vs rest (Kolkata metropolitan districts)
metro = ["Kolkata", "Haora", "North 24 Parganas", "South 24 Parganas", "Hugli"]
res["metro"] = res.district.isin(metro)
grp = res.groupby("metro").agg(pop=("population", "sum"), light=("ntl_sum", "sum"), gddp=("gddp", "sum"))
share = (grp / grp.sum() * 100)
pc = (grp.light / grp["pop"])
ratio = pc[True] / pc[False]

# 4. Moran's I (queen/touch contiguity, row-standardised, 999 permutations)
g = gpd.read_file("wb_districts_boundary.shp").rename(columns={"ADM2_NAME": "district"})
g = g.merge(res[["district", "gddp", "mpi", "ln_resid"]], on="district")
n = len(g); W = np.zeros((n, n))
for i in range(n):
    for j in range(n):
        if i != j and g.geometry[i].buffer(1e-4).intersects(g.geometry[j]): W[i, j] = 1
W = W / W.sum(1, keepdims=True)
def moran(v, seed=1):
    v = np.asarray(v, float); z = v - v.mean(); I = (z @ W @ z) / (z @ z)
    rng = np.random.default_rng(seed)
    sims = [(lambda p: (p @ W @ p) / (p @ p))(rng.permutation(z)) for _ in range(999)]
    return I, (np.sum(np.abs(sims) >= abs(I)) + 1) / 1000
mi = {k: moran(g[k]) for k in ["gddp", "mpi", "ln_resid"]}

# ---- figures ----
fig, ax = plt.subplots(1, 2, figsize=(11, 4.6))
c = cagr.sort_values()
ax[0].barh(c.index, c.values, color="#2A5D8F"); ax[0].axvline(state_cagr, color="r", ls="--", lw=1)
ax[0].set_xlabel("NTL growth, % per year (2014-2021)"); ax[0].set_title("Annual growth of nighttime light")
for yr, col, vals in [(2014, "tab:orange", a.values), (2021, "tab:blue", b.values)]:
    x, y = lorenz(vals); ax[1].plot(x, y, c=col, label=f"{yr} (Gini {gini(vals):.2f})")
ax[1].plot([0, 1], [0, 1], "k--", lw=1); ax[1].set_xlabel("Cumulative share of districts"); ax[1].set_ylabel("Cumulative share of light")
ax[1].set_title("Lorenz curve of district NTL"); ax[1].legend()
plt.tight_layout(); plt.savefig(f"{OUT}/extra_growth_lorenz.png", dpi=200); plt.close()

plt.figure(figsize=(6.5, 4.2)); w = .25
for k, (lab, col) in enumerate([("pop", "Population"), ("light", "Nighttime light"), ("gddp", "GDDP")]):
    plt.bar(np.arange(2) + (k - 1) * w, [share.loc[True, lab], share.loc[False, lab]], w, label=col)
plt.xticks(range(2), ["Kolkata metro districts (5)", "Other districts (14)"]); plt.ylabel("Share of state total (%)")
plt.title("Metro vs rest of West Bengal, 2021"); plt.legend(); plt.tight_layout(); plt.savefig(f"{OUT}/extra_metro_share.png", dpi=200); plt.close()

out = dict(cagr=cagr.round(1).to_dict(), state_cagr=round(state_cagr, 1), gini14=round(g14, 3), gini21=round(g21, 3),
           gini_pc=round(gpc, 3), gini_gddp=round(gg, 3), share=share.round(1).to_dict(), pc_ratio=round(ratio, 2),
           moran={k: [round(v[0], 3), v[1]] for k, v in mi.items()})
json.dump(out, open(f"{OUT}/extra_results.json", "w"), indent=1); print(json.dumps(out, indent=1))
